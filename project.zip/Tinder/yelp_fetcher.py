import requests

YELP_API_KEY = "3CDquv2YIfVJBzNuoyau9lsDbqv21Zohj2ewjXvFlJDovEAGaiJWihHDxImRJatHXFA--wY1vVGuvLUX2bMyS-ipwsXjyDII3afybeUrgoisA1GbR8o0oOSB5bIYaHYx"

HEADERS = {
    "Authorization": f"Bearer {YELP_API_KEY}"
}

def geocode_location(location_str):
    """Geocode a location name to latitude and longitude using OpenStreetMap."""
    url = "https://nominatim.openstreetmap.org/search"
    params = {"q": location_str, "format": "json", "limit": 1, "countrycodes": "ch"}
    headers = {"User-Agent": "TinderActivitiesApp/1.0"}
    try:
        response = requests.get(url, params=params, headers=headers, timeout=10)
        data = response.json()
        if data:
            lat = float(data[0]["lat"]); lon = float(data[0]["lon"])
            return lat, lon
    except Exception:
        return None

def fetch_yelp_activities(lat, lon, term="activities", radius_m=5000, limit=20):
    """Fetch activities from the Yelp API based on a search term and location."""
    url = "https://api.yelp.com/v3/businesses/search"
    params = {
        "latitude": lat, "longitude": lon,
        "term": term, "radius": radius_m, "limit": limit
    }
    try:
        response = requests.get(url, headers=HEADERS, params=params, timeout=10)
        data = response.json()
        results = []
        for biz in data.get("businesses", []):
            results.append({
                "name": biz.get("name"),
                "lat": biz["coordinates"]["latitude"],
                "lon": biz["coordinates"]["longitude"],
                "rating": biz.get("rating", "N/A"),
                "category": biz.get("categories")[0]["title"] if biz.get("categories") else "Activity",
                "address": ", ".join(biz["location"].get("display_address", [])),
                "image_url": biz.get("image_url"),
                "photos": biz.get("photos", []),
                "url": biz.get("url"),
                "price": biz.get("price", "")
            })
        return results
    except Exception as e:
        print("Yelp API error:", e)
        return []

def fetch_eventfrog_events(lat, lon, term="events", radius_m=5000):
    """
    Fetch events (concerts/parties) from Eventfrog's API based on location.
    Returns a list of events with name, location, date, and other details.
    """
    # Base URL and parameters for the Eventfrog events API (public events search)
    base_url = "https://api.eventfrog.ch/api/events"  # hypothetical endpoint
    params = {
        "latitude": lat,
        "longitude": lon,
        "distance": radius_m
    }
    # Filter by keyword if looking specifically for concerts or parties
    if term.lower() in ["concerts", "concert", "gig"]:
        params["keyword"] = "concert"
    elif term.lower() in ["parties", "party", "club"]:
        params["keyword"] = "party"

    events = []
    try:
        response = requests.get(base_url, params=params, timeout=10)
        data = response.json()
        for ev in data.get("events", data.get("data", [])):
            # Extract event details (assuming keys based on Eventfrog's data model)
            name = ev.get("title") or ev.get("name")
            loc_name = ev.get("locationName") or (ev.get("location", {}).get("name") if ev.get("location") else "")
            loc_city = ev.get("locationCity") or (ev.get("location", {}).get("city") if ev.get("location") else "")
            address = f"{loc_name}, {loc_city}" if loc_name else loc_city
            # Use primary coordinates if available
            ev_lat = ev.get("latitude") or (ev.get("location", {}).get("latitude") if ev.get("location") else None)
            ev_lon = ev.get("longitude") or (ev.get("location", {}).get("longitude") if ev.get("location") else None)
            date = ev.get("startDate") or ev.get("date") or ev.get("datetime") or ""
            url = ev.get("url") or ev.get("eventUrl") or ""
            events.append({
                "name": name or "Untitled Event",
                "lat": ev_lat,
                "lon": ev_lon,
                "rating": "",  # events have no Yelp rating
                "category": "Concert" if params.get("keyword") == "concert" else ("Party" if params.get("keyword") == "party" else "Event"),
                "address": address,
                "image_url": ev.get("imageUrl") or "",
                "photos": ev.get("images", []),
                "url": url,
                "price": ev.get("ticketPrice", "") or ev.get("price", ""),
                "date": date
            })
    except Exception as e:
        print("Eventfrog API error:", e)
    return events
