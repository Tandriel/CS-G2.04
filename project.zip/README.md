# CS-G2.04
This is our repository for our amazing and wonderful Website

Activity Tinder 

- first, choose Location and type of activity 
  - then swipe from all the choices our app gives you, header by a picture 

- once you swipe right, get additional information for your selected activity, including:
  - Name & Location
  - distance from User
  - Weather 
  - how to get there (public transport)
  -